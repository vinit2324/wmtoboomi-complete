webMethods Golden Test Suite v5 (NS/enterprise)

Starting point: v4 suite.
v5 adds breadth to approximate a Fortune-500 landscape.

Added in v5:
- 18 JDBC select-style services across OTC, PTP, Finance, HLS, Manufacturing, and Utilities.
- 2 orchestration flows calling multiple downstream services with Catch blocks.
- 5 additional retry wrappers (repeat/until + dynamic invoke).
- 3 adapter-style services (JDBC insert, SAP BAPI, SFDC upsert) with wrapper flows to enforce 2-file rule.
- 4 additional canonical document types (Invoice, Shipment, PaymentBatch, Observation).
- Broker/UM document type simulation (OrderEvent).

Total new components in v5: 33 (approx; node+logic counted as one)

All contents preserve:
- strict two-file separation per component
- NS/enterprise namespace
- webMethods 9.x/10.x flow patterns (SEQUENCE/BRANCH/LOOP/REPEAT/CATCH/MAP/INVOKE).
