webMethods Golden Test Suite v3 (NS/enterprise)

Includes:
- 13 original components from v2 (Order-to-Cash, Procure-to-Pay, Utilities, EDI, Canonical docs)
- 18 new components:
  * EDI 856 ASN outbound (sendASN)
  * EDI 997 inbound ACK handler (receive997)
  * REST provider DB query (getOrders)
  * JMS consumer (consumeOrder)
  * Trading Networks profile lookup (getTradingPartner)
  * Retry utility with backoff and dynamic invoke (notifyAndRetry)
  * File poller CSV ingestion (ingestCustomers) + CustomerCSV schema + Customer doc type
  * SOAP provider invoice processor (processInvoice) + validateInvoice
  * Metrics push to lake with HMAC (pushToLake)
  * Circuit breaker utility (circuitBreaker)
  * SFDC PATCH update with retry on rate-limit (updateOppStatus)
  * Nightly purge batch (purgeStaging)
  * EDI 856 + 997 schemas

Strict two-file separation is preserved for all services and schemas.
