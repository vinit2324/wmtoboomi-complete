webMethods Golden Test Suite v6 (NS/enterprise)

v6 expands v5 into a large, production-like ingestion corpus.

Added in v6:
- 60 bulk JDBC select services with optional empty-result branching.
- 25 bulk JDBC insert services.
- 15 REST call services with 429 retry logic.
- 8 Trading Networks routing-rule simulations (partner variants).
- 10 edge-case flows (multi-catch, exit variants, pipeline save/restore).
- 8 additional X12 EDI schemas (855/860/867/943/944/990/214/753).

New files added (count): 252
Approx new components (node+logic pairs): ~126

All artifacts preserve:
- strict two-file separation per component
- NS/enterprise namespace
- webMethods 9.x/10.x style Flow XML.
