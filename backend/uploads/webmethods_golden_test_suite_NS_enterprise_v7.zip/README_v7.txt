webMethods Golden Test Suite v7 (NS/enterprise)

v7 expands v6 with true adapter-style node.ndf blocks, multiple trigger types, schedulers, and additional weird flow patterns.

Added in v7:
- 20 JDBC adapter services with full adapterService blocks + wrapper flows.
- 10 SAP adapter services (BAPI/IDOC) + wrappers.
- 8 Salesforce adapter services + wrappers.
- 2 new Broker document types (InvoiceEvent, ShipmentEvent).
- 12 Broker triggers (trigger node type) + flows that call downstream services.
- 10 Scheduler job nodes + wrapper flows.
- 30 weird/edge flows (switch label expressions, nested repeats, try/catch/finally).
- 12 file polling triggers + flows.

New files added: 208 (approx new components ~102)

All artifacts preserve:
- strict two-file separation per component
- NS/enterprise namespace
- webMethods 9.x/10.x flow patterns.
